﻿using System.Threading;
using OpenQA.Selenium;
using NUnit.Framework;
using OpenQA.Selenium.Interactions;

namespace Automation_Manage_Memberships
{
    public class DeleteMembership
    {
        [Test]
        public static void g_FindAddedRecord(IWebDriver driver)
        {

            //Navigate to membership
            driver.FindElement(By.XPath("//a[@id='membership_entity']/span")).Click();
            Thread.Sleep(1200);
            driver.FindElement(By.XPath(" //div[@id='grid']/div")).Click();
            Thread.Sleep(1200);

            var sort1 = driver.FindElement(By.LinkText("Membership Id"));
            sort1.Click();
            sort1.Click();
            Thread.Sleep(500);


            //Edit membership
            driver.FindElement(By.Id("updatebtn")).Click();
            Thread.Sleep(1000);

            //update cancel
            driver.FindElement(By.XPath("//div[@id='item-update-modal']/div/fieldset/span/span/input")).SendKeys("Health Issue");
            Thread.Sleep(500);
            //update plan 
            var plan = driver.FindElement(By.XPath("//div[@id='plan-data-update']/span/span/input"));
            plan.Clear();
            plan.SendKeys("General Plan");
            Thread.Sleep(500);
            //update types
            var types = driver.FindElement(By.XPath("//div[@id='type-data-update']/span/span/input"));
            types.Clear();
            types.SendKeys("General Membership");
            Thread.Sleep(500);
            //update terms & Benefits
            for (int i = 5; i >= 1; i--)
            {
                driver.FindElement(By.XPath($"//div[@id='new-all-terms']/input[{i}]")).Click();
                Thread.Sleep(500);
                driver.FindElement(By.XPath($"//div[@id='new-all-benefits']/input[{i}]")).Click();
                Thread.Sleep(500);
                break;
            }
            //update
            driver.FindElement(By.XPath("//div[@id='item-update-modal']/div/fieldset/button")).Click();
            Thread.Sleep(1000);
            sort1.Click();
            sort1.Click();
            //Delete Membership
            driver.FindElement(By.Id("deletebtn")).Click();
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//div[@id='item-delete-confirm-modal']/div/button")).Click();
            Thread.Sleep(1000);
        }

        [Test]
        public static void h_DeleteSetups(IWebDriver driver)
        {
            //Setup-Benefit navigation
            driver.FindElement(By.XPath("//a[@id='membership_menu']/span")).Click();
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//a[@id='membership_benefits']/span")).Click();
            Thread.Sleep(1000);

            var sort1 = driver.FindElement(By.LinkText("Benefit Id"));
            sort1.Click();
            sort1.Click();
            //Update
            driver.FindElement(By.Id("updatebtn")).Click();
            Thread.Sleep(500);
            var newName = driver.FindElement(By.Id("new-name"));
            newName.Clear();
            newName.SendKeys("General Benefit Discount");
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//div[@id='item-update-modal']/div/fieldset/button")).Click();
            Thread.Sleep(500);
            //Delete Benefit
            sort1.Click();
            sort1.Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("//div[@id='grid']/div[3]/table/tbody/tr/td[5]/button")).Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("//div[@id='item-delete-confirm-modal']/div/button")).Click();
            Thread.Sleep(500);

            //Plan navigation
            driver.FindElement(By.XPath("//a[@id='membership_plans']/span")).Click();
            Thread.Sleep(1000);
            var sort2 = driver.FindElement(By.LinkText("Plan Id"));
            sort2.Click();
            sort2.Click();
            //Delete PLan
            driver.FindElement(By.XPath("//div[@id='grid']/div[3]/table/tbody/tr/td[6]/button")).Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("//div[@id='item-delete-confirm-modal']/div/button")).Click();
            Thread.Sleep(500);

            //Term navigation
            driver.FindElement(By.XPath("//a[@id='membership_terms']/span")).Click();
            Thread.Sleep(1000);
            var sort3 = driver.FindElement(By.LinkText("Term Id"));
            sort3.Click();
            sort3.Click();
            //Delete Term
            driver.FindElement(By.XPath("//div[@id='grid']/div[3]/table/tbody/tr/td[5]/button")).Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("//div[@id='item-delete-confirm-modal']/div/button")).Click();
            Thread.Sleep(500);

            //Type navigation
            driver.FindElement(By.XPath("//a[@id='membership_types']/span")).Click();
            Thread.Sleep(1000);
            var sort4 = driver.FindElement(By.LinkText("Type Id"));
            sort4.Click();
            sort4.Click();
            //Delete type
            driver.FindElement(By.XPath("//div[@id='grid']/div[3]/table/tbody/tr/td[5]/button")).Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("//div[@id='item-delete-confirm-modal']/div/button")).Click();
            Thread.Sleep(500);

            //Cancellation navigation
            driver.FindElement(By.XPath("//a[@id='membership_cancellation_reason']/span")).Click();
            Thread.Sleep(1000);
            var sort5 = driver.FindElement(By.LinkText("Reason Id"));
            sort5.Click();
            sort5.Click();
            //Delete cancel reason
            driver.FindElement(By.XPath("//div[@id='grid']/div[3]/table/tbody/tr/td[5]/button")).Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("//div[@id='item-delete-confirm-modal']/div/button")).Click();
            Thread.Sleep(500);
        }
    }
}

﻿using System.Threading;
using OpenQA.Selenium;
using NUnit.Framework;
using OpenQA.Selenium.Interactions;



namespace Automation_Manage_Memberships
{
    [TestFixture]
    public class Membership
    {
        [Test]
        public static void a_ManageMembership(IWebDriver driver)
        {
            //Navigate to Manage Membership
            driver.FindElement(By.XPath("//a[@id='managememberships']/span")).Click();
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//a[@id='membership_entity']/span")).Click();
            Thread.Sleep(1200);
            //Navigate to Add new membership
            driver.FindElement(By.Id("loadsavedivdtn")).Click();
            Thread.Sleep(1000);
            //Add New Membership
            driver.FindElement(By.Id("name")).SendKeys("General Membership");
            Thread.Sleep(300);
            driver.FindElement(By.Id("desc")).SendKeys("General Member");
            Thread.Sleep(300);
            //Add Category
            driver.FindElement(By.XPath("//div[@id='basic-data-insert']/span[3]/span/span")).Click();
            Thread.Sleep(300);
            driver.FindElement(By.XPath("//ul[@id='membershipcategory_listbox']/li")).Click();
            Thread.Sleep(300);
            //validity
            driver.FindElement(By.XPath("//div[@id='categorybasedlimitinputholder']/span/span/input[2]")).SendKeys("12");
            Thread.Sleep(1000);
            //fee
            driver.FindElement(By.XPath("//div[@id='basic-data-insert']/span[5]/span/input[2]")).SendKeys("1000");
            Thread.Sleep(300);
            //discount
            driver.FindElement(By.XPath("//div[@id='basic-data-insert']/span[7]/span/input[2]")).SendKeys("10");
            Thread.Sleep(300);

            //status
            driver.FindElement(By.XPath("//div[@id='basic-data-insert']/span[9]/span/span")).Click();
            Thread.Sleep(300);
            driver.FindElement(By.XPath("//ul[@id='status_listbox']/li")).Click();
            Thread.Sleep(300);

            //sub accounts
            driver.FindElement(By.Id("isappliedfordiscount")).Click();
            Thread.Sleep(300);
            driver.FindElement(By.Id("appliedforsubaccounts")).Click();
            Thread.Sleep(300);

            //Plan Option
            var plan = driver.FindElement(By.XPath("//div[@id='plan-data-insert']/span/span/input"));
            plan.SendKeys("Ev");
            Thread.Sleep(1000);
            plan.Click();
            Thread.Sleep(1000);
            Actions builder = new Actions(driver);
            builder.SendKeys(Keys.Tab);

            //Type option
            var type = driver.FindElement(By.XPath("//div[@id='type-data-insert']/span/span/input"));
            type.SendKeys("Bronze");
            Thread.Sleep(1000);
            type.Click();
            Thread.Sleep(1000);

            builder.SendKeys(Keys.Tab);

            //Terms
            for (int i = 1; i < 10; i++)
            {
                //term
                driver.FindElement(By.XPath($"//div[@id='all-terms']/input[{i}]")).Click();
                Thread.Sleep(500);
                // benefit
                driver.FindElement(By.XPath($"//div[@id='all-benefits']/input[{i}]")).Click();
                Thread.Sleep(500);
                break;
            }
            //save
            driver.FindElement(By.XPath("//div[@id='additemsection']/fieldset/button")).Click();
            Thread.Sleep(1000);
        }

        [Test]
        public static void b_assignUser(IWebDriver driver)
        {
            //Navigate to assign user
            driver.FindElement(By.XPath("//a[@id='adminassignedusermemberships']/span")).Click();
            Thread.Sleep(1000);
            //Membership-user select, assign
            var memName = driver.FindElement(By.XPath("//div[@id='membership-combo-list-container']/span/span/input"));
            memName.SendKeys("General Membership");
            memName.Click();
            Thread.Sleep(1000);
            var userName = driver.FindElement(By.XPath("//div[@id='users-combo-list-container']/span/input"));
            userName.SendKeys("Townsuite1 Administrator1 ");
            driver.FindElement(By.XPath("//ul[@id='all-users_listbox']/li")).Click();
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//div[@id='assignment-info-container']/button")).Click();
            Thread.Sleep(1000);
        }

        [Test]
        public static void c_ViewMembership(IWebDriver driver)
        {
            //Navigate to membership
            driver.FindElement(By.XPath("//body[@id='thebody']/div/aside/div/nav/ul/li[11]/a")).Click();
            Thread.Sleep(1000);
            //Select created/assigned membership
            driver.FindElement(By.XPath("//form[@id='aspnetForm']/div[2]/div/div/h1/fieldset/div/div/div/input")).SendKeys("General Membership");
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//form[@id='aspnetForm']/div[2]/div/div/h1/fieldset/div/div/div/div/button")).Click();
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//div[@id='infinite-container']/div/div/a/div/img")).Click();
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//div[@id='eventheadertext']/a")).Click();
            Thread.Sleep(1000);           
        }
    }
}


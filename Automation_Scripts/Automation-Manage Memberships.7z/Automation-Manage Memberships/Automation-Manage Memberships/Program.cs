﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using NUnit.Framework;

namespace Automation_Manage_Memberships
{
    [TestFixture]
   public class Program
    {
        [Test]
         static void Main(string[] args)
        {
            IWebDriver driver = new FirefoxDriver();
            Login.a_login(driver);
            Thread.Sleep(1000);
            /*
            Membership.a_ManageMembership(driver);
            Thread.Sleep(1000);
            //Membership.b_assignUser(driver);
            //Thread.Sleep(1000);
            Membership.c_ViewMembership(driver);
            Thread.Sleep(1000);

            Membership_Reports.a_DetailReport(driver);
            Thread.Sleep(1000);
           
            
            MembershipSetupcs.b_AddBenefit(driver);
            Thread.Sleep(1000);
            MembershipSetupcs.c_AddPlans(driver);
            Thread.Sleep(1000);
            MembershipSetupcs.d_AddTerms(driver);
            Thread.Sleep(1000);
            MembershipSetupcs.e_AddTypes(driver);
            Thread.Sleep(1000);
            MembershipSetupcs.f_AddCancellation(driver);
            Thread.Sleep(1000);
          */

            DeleteMembership.g_FindAddedRecord(driver);
            Thread.Sleep(1000);
            DeleteMembership.h_DeleteSetups(driver);
            Thread.Sleep(1000);
            

            /*
            Membership_Reports.a_DetailReport(driver);
            Thread.Sleep(1000);
            Membership_Reports.b_MonthlyReport(driver);
            Thread.Sleep(1000);
            */

        }
    }
}















































//public static void l_AddNewCancellation(IWebDriver driver)
//{
//    //driver.FindElement(By.XPath("//a[@id='membership_menu']/em")).Click();
//    //Thread.Sleep(1000);

//    driver.FindElement(By.XPath("//a[@id='membership_cancellation_reason']/span")).Click();
//    Thread.Sleep(1000);

//    driver.FindElement(By.XPath("//div[@id='additembutton']/button")).Click();
//    Thread.Sleep(500);

//    driver.FindElement(By.XPath("//div[@id='additemsection']/fieldset/input")).SendKeys("Unhealthy");
//    Thread.Sleep(500);

//    driver.FindElement(By.XPath("//div[@id='additemsection']/fieldset/input[2]")).SendKeys("Unfit");
//    Thread.Sleep(500);

//    driver.FindElement(By.XPath("//div[@id='additemsection']/fieldset/button")).Click();
//    Thread.Sleep(500);

//    Console.WriteLine("Record added successfully..");
//    Thread.Sleep(300);

//}
﻿using System.Threading;
using OpenQA.Selenium;
using NUnit.Framework;
using OpenQA.Selenium.Interactions;

namespace Automation_Manage_Memberships
{
    public class MembershipSetupcs
    {
        [Test]
        public static void b_AddBenefit(IWebDriver driver)
        {
            //Setup-Benefit navigation
            driver.FindElement(By.XPath("//a[@id='membership_menu']/span")).Click();
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//a[@id='membership_benefits']/span")).Click();
            Thread.Sleep(1000);
            //Add benfit
            driver.FindElement(By.XPath("//div[@id='additembutton']/button")).Click();
            Thread.Sleep(1000);
            //Name-Desc-Save
            driver.FindElement(By.XPath("//div[@id='additemsection']/fieldset/input")).SendKeys("General Benefit");
            Thread.Sleep(1000);
            driver.FindElement(By.XPath("//div[@id='additemsection']/fieldset/input[2]")).SendKeys("5% discount will be given on cash payment");
            Thread.Sleep(1000);

            driver.FindElement(By.XPath("//div[@id='additemsection']/fieldset/button")).Click();
            Thread.Sleep(2000);
        }

        [Test]
        public static void c_AddPlans(IWebDriver driver)
        {
            //Plan navigation
            driver.FindElement(By.XPath("//a[@id='membership_plans']/span")).Click();
            Thread.Sleep(1000);
            //Add plan
            driver.FindElement(By.XPath("//div[@id='additembutton']/button")).Click();
            Thread.Sleep(1000);
            //Name-Desc-Age-Save
            driver.FindElement(By.Id("name")).SendKeys("General Plan");
            Thread.Sleep(1000);
            driver.FindElement(By.Id("desc")).SendKeys("This plan is for adults with age above nineteen");
            Thread.Sleep(1000);
            driver.FindElement(By.Id("minage")).SendKeys("19");
            Thread.Sleep(1000);

            driver.FindElement(By.XPath("//div[@id='additemsection']/fieldset/button")).Click();
            Thread.Sleep(2000);
        }

        [Test]
        public static void d_AddTerms(IWebDriver driver)
        {
            //Term navigation
            driver.FindElement(By.XPath("//a[@id='membership_terms']/span")).Click();
            Thread.Sleep(1000);
            //Add Term
            driver.FindElement(By.XPath("//div[@id='additembutton']/button")).Click();
            Thread.Sleep(1000);
            //Name-Desc-Save
            driver.FindElement(By.Id("name")).SendKeys("General Term");
            Thread.Sleep(1000);
            driver.FindElement(By.Id("desc")).SendKeys("Limitation of Liability");
            Thread.Sleep(1000);

            driver.FindElement(By.XPath("//div[@id='additemsection']/fieldset/button")).Click();
            Thread.Sleep(2000);
        }

        [Test]
        public static void e_AddTypes(IWebDriver driver)
        {
            //Type navigation
            driver.FindElement(By.XPath("//a[@id='membership_types']/span")).Click();
            Thread.Sleep(1000);
            //Add Type
            driver.FindElement(By.XPath("//div[@id='additembutton']/button")).Click();
            Thread.Sleep(1000);
            //Name-Desc-Save
            driver.FindElement(By.Id("name")).SendKeys("General Membership");
            Thread.Sleep(1000);
            driver.FindElement(By.Id("desc")).SendKeys("For general account holders");
            Thread.Sleep(1000);

            driver.FindElement(By.XPath("//div[@id='additemsection']/fieldset/button")).Click();
            Thread.Sleep(2000);
        }

        [Test]
        public static void f_AddCancellation(IWebDriver driver)
        {
            //Cancellation navigation
            driver.FindElement(By.XPath("//a[@id='membership_cancellation_reason']/span")).Click();
            Thread.Sleep(1000);
            //Add Cancel Reason
            driver.FindElement(By.XPath("//div[@id='additembutton']/button")).Click();
            Thread.Sleep(1000);
            //Name-Desc-Save
            driver.FindElement(By.Id("name")).SendKeys("Health Issue");
            Thread.Sleep(1000);
            driver.FindElement(By.Id("desc")).SendKeys("Lack of good health and unfitness");
            Thread.Sleep(1000);

            driver.FindElement(By.XPath("//div[@id='additemsection']/fieldset/button")).Click();
            Thread.Sleep(2000);
        }
    }
}

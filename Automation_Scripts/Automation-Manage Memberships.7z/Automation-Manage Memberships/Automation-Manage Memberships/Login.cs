﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using NUnit.Framework;

namespace Automation_Manage_Memberships
{
    public class Login
    {
        public static void a_login(IWebDriver driver)
        {
            //string baseURL = "http://172.16.5.181:8084/";
            string baseURL = "http://lk1.dev.townsuite.com:8078/login";
            //string baseURL = "http://lk1.dev.townsuite.com:8088/login";
            driver.Navigate().GoToUrl(baseURL);
            driver.Manage().Window.Maximize();
            driver.FindElement(By.Id("LoginUserName")).SendKeys("admintestuser@townsuite.com");
            driver.FindElement(By.Id("LoginPassword")).SendKeys("Password3");
            driver.FindElement(By.Id("LoginButton")).Click();
            driver.Manage().Timeouts().ImplicitlyWait(new TimeSpan(0, 0, 40000000));
        }
    }
}

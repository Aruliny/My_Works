﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using NUnit.Framework;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System.Diagnostics;



namespace Automation_Manage_Memberships
{
    [TestFixture]
    public class Membership_Reports
    {
        [Test]
        public static void a_DetailReport(IWebDriver driver)
        {
            driver.FindElement(By.XPath("//a[@id='managememberships']/span")).Click();
            Thread.Sleep(300);           
            driver.FindElement(By.XPath("//a[@id='membership_report_menu']/em")).Click();
            Thread.Sleep(300);
            driver.FindElement(By.XPath("//a[@id='membership_detail_report']/span")).Click();
            Thread.Sleep(1000);

            //Search for record
            driver.FindElement(By.XPath("//div[@id='membership-name-combo-list-container']/span/span/input")).SendKeys("General Membership");
            Thread.Sleep(500);
            driver.FindElement(By.XPath("//div[@id='status-list-container']/span/span/span[2]")).Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("//ul[@id='membership-status_listbox']/li")).Click();
            Thread.Sleep(1000);

            //Generate & Print
            driver.FindElement(By.XPath("//div[@id='generate-report-btn-container']/button")).Click();
            Thread.Sleep(500);
            driver.FindElement(By.XPath("//div[@id='report-print-btn-container']/button")).Click();
            Thread.Sleep(1000);          
        }

        [Test]
        public static void b_MonthlyReport(IWebDriver driver)
        {
            driver.FindElement(By.XPath("//a[@id='membership_monthly_usage_report']/span")).Click();
            Thread.Sleep(500);

            var start_date = driver.FindElement(By.XPath("//div[@id='fee-input-container']/span/span/input")).Text;
            var end_date = driver.FindElement(By.XPath("//div[@id='discount-input-container']/span/span/input"));
            var today_date = DateTime.Today;           


        }
        //a[@id='membership_monthly_usage_report']/span

    }
}
